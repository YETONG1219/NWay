package Graphviz;

import java.io.File;
import java.util.ArrayList;

public class test {
    public static void main(String[] args, ArrayList<String> readList, ArrayList<String> readListr){
        test gtest = new test();
        String[] nodes = new String [readList.size()];
        String[] preline = new String [readListr.size()];
        for(int i=0; i<readList.size();i++)
        	nodes[i]=readList.toArray()[i].toString();
        for(int i=0; i<readListr.size();i++)
        	preline[i]=readListr.toArray()[i].toString().split(" ")[0] + " -> " + readListr.toArray()[i].toString().split(" ")[1];
//        String[] nodes = {"version1_u1","version1_u2","version1_u3","version1_u4","version1_mer1","version2"};
//        String[] preline = {"version1_u1 -> version1_mer1","version1_u2 -> version1_mer1","version1_u3 -> version1_mer1","version1_u4 -> version1_mer1","version1_mer1 -> version2"};
       gtest.start(nodes, preline);
    }
    private void start(String[] nodes,String[] preline){
           
           GraphViz gv = new GraphViz();
           //����ÿ���ڵ��style
           String nodesty = "[shape = polygon, sides = 4, peripheries = 2, color = lightblue, style = filled]";
           //String linesty = "[dir=\"none\"]";
           
           gv.addln(gv.start_graph());//SATRT
           gv.addln("edge[fontname=\"edge\" fontsize=15 fontcolor=\"black\" color=\"black\" style=\"filled\"]");
           gv.addln("size =\"5,5\";");
           //���ýڵ��style
           for(int i=0;i<nodes.length;i++){
               gv.addln(nodes[i]+" "+nodesty);
           }
           for(int i=0;i<preline.length;i++){
//               gv.addln(preline[i]+" "+" [dir=\"none\"]");
               gv.addln(preline[i]);
           }
           gv.addln(gv.end_graph());//END
           //�ڵ�֮������ӹ�ϵ���������̨
           System.out.println(gv.getDotSource());
           //���ʲô��ʽ��ͼƬ(gif,dot,fig,pdf,ps,svg,png,plain)
           String type = "png";
           //������ļ����Լ�����
           File out = new File("E:/eclipse/com.Nway/Models/pic/test." + type); 
           gv.writeGraphToFile( gv.getGraph( gv.getDotSource(), type ), out );
       }
}