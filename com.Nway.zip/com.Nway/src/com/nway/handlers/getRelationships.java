package com.nway.handlers;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.nway.utils.ClassType;
import com.nway.utils.RelationType;

public class getRelationships {
	//Read N versions xml to get relationships
		public static Map<String, List<RelationType>> main( String[] selectedVersions) throws DocumentException{
//	public static void main( String[] args) throws DocumentException{
//    	String[] selectedVersions=new String [3];//�ӽ��洫��,�ϲ��ĸ����汾��


			Map<String, List<RelationType>> VersionsRelationshipsList = new HashMap<String, List<RelationType>>();
			Map<String, List<ClassType>> VersionsClassList =readXML.main(selectedVersions);
	       for(int i=0;i<selectedVersions.length;i++) {
	    	   String projectPath = System.getProperty("user.dir");
	    	   String dir = projectPath + "\\Models";
	    	   String fileName= dir+"\\"+selectedVersions[i]+"\\"+selectedVersions[i]+".uml";
	    	   System.out.println("====getRelationships: main--�� "+i +"��Ҫ�ϲ��İ汾�ļ�����"+fileName);
	    	   File xmlFile = new File(fileName);// ����ָ����·������file����
	    	   SAXReader sax = new SAXReader();// ����һ��SAXReader����
	    	   Document document = sax.read(xmlFile);// ��ȡdocument����,����ĵ��޽ڵ㣬����׳�Exception��ǰ����
	    	   
	    	   Element root = document.getRootElement();// ��ȡ���ڵ�
	    	   List<RelationType> OneVersionRelationshipsList = new ArrayList<RelationType>();
	    	   OneVersionRelationshipsList =getRelationshipsOneVersion( VersionsClassList,OneVersionRelationshipsList,root,selectedVersions[i]);
//	    	   System.out.println("====getRelationships: main--listsize"+OneVersionRelationshipsList.size());
	    	   VersionsRelationshipsList.put(selectedVersions[i],OneVersionRelationshipsList);
	    	  
	       }
	       for(String version:VersionsRelationshipsList.keySet()) {
	           System.out.println("====getRelationships: main----�汾"+version+"��relationship���б�");
	           List<RelationType> OneVersionRList = VersionsRelationshipsList.get(version);
	           for(RelationType R:OneVersionRList) {
	        	   System.out.println("___________________________________________________");
		           System.out.println("		type: "+R.getType());
		           System.out.println("		version: "+R.getVersion());
		           System.out.println("		ID: "+R.getID());
		           System.out.println("		source: "+R.getSourceName()+"	des: "+R.getDestinationName());
		           if(R.getType().equals("uml:Dependency")==false && R.getType().equals("uml:Generalization")==false)
			           System.out.println("		������: "+R.getlowerValue()+"..."+R.getupperValue());

		          
	           }
	       }
	   	return VersionsRelationshipsList;
		}
	private static List<RelationType> getRelationshipsOneVersion(Map<String, List<ClassType>> VersionsClassList,List<RelationType> list,Element node,String version) {
		String type = node.attributeValue("type");
        System.out.println("		====getRelationships:getRelationshipsOneVersion: type "+type);

		if (type!=null&&type.equals("uml:Dependency")) {
//	        System.out.println("		====getRelationships:getRelationshipsOneVersion: �汾 "+version+"	des: "+node.attributeValue("supplier"));
			RelationType relationship = new RelationType();
			relationship.setType(type);
			relationship.setVersion(version);
			String sourceID = node.attributeValue("client");
	        String sourceName =getClassNameByID(VersionsClassList,version,sourceID);
			String destinationID = node.attributeValue("supplier");
	        String destinationName = getClassNameByID(VersionsClassList,version,destinationID);
	        System.out.println("		====getRelationships: uml:Dependency����   source: "+sourceName+"	des: "+destinationName);
	        System.out.println("		====getRelationships: uml:Dependency����   sourceID: "+sourceID+"	desID: "+destinationID);

			relationship.setSourceID(sourceID);
			relationship.setSourceName(sourceName);
			relationship.setDestinationID(destinationID);
			relationship.setDestinationName(destinationName);
			String ID = version+"Dependency"+sourceName+destinationName+"id";
			relationship.setID(ID);
		
			list.add(relationship);
		}
		if (type!=null&&type.equals("uml:Generalization")) {
			Element parent = node.getParent();
			String sourceName = parent.attributeValue("name");
			String sourceID = parent.attributeValue("id");
			RelationType relationship = new RelationType();
			relationship.setType(type);
			relationship.setVersion(version);
			String destinationID = node.attributeValue("general");
	        String destinationName = getClassNameByID(VersionsClassList,version,destinationID);
	        
	        System.out.println("		====getRelationships: uml:Generalization����   source: "+sourceName+"	des: "+destinationName);
	        System.out.println("		====getRelationships: uml:Generalization����   sourceID: "+sourceID+"	desID: "+destinationID);
			relationship.setSourceID(sourceID);
			relationship.setSourceName(sourceName);
			relationship.setDestinationID(destinationID);
			relationship.setDestinationName(destinationName);
			String ID = version+"Generalization"+sourceName+destinationName+"id";
			relationship.setID(ID);
		
			list.add(relationship);
		}
		if (node.attributeValue("aggregation")!=null && node.attributeValue("aggregation").equals("composite")) {
	        System.out.println("		====getRelationships:getRelationshipsOneVersion: ���");
			Element parent = node.getParent();
			String sourceName = parent.attributeValue("name");
			String sourceID = parent.attributeValue("id");
			RelationType relationship = new RelationType();
			relationship.setType("Composite");
			relationship.setVersion(version);
			String destinationID = node.attributeValue("id");
	        String destinationName =  node.attributeValue("name");
	        System.out.println("		====getRelationships: ���   source "+sourceName+"	des: "+destinationName);
	        System.out.println("		====getRelationships: ���   sourceid "+sourceID+"	desid: "+destinationID);

	        Element lowerElement =node.element("lowerValue");// ��ȡ�ӽڵ�
	        Element upperElement =node.element("upperValue");// ��ȡ�ӽڵ�
	        int lower = 0;
	        int upper = 0;
	        if(lowerElement.attributeValue("value")!=null)
	        	lower = Integer.parseInt(lowerElement.attributeValue("value"));
	        if(upperElement.attributeValue("value")!=null)
	            upper = Integer.parseInt(upperElement.attributeValue("value"));
	           
			relationship.setSourceID(sourceID);
			relationship.setSourceName(sourceName);
			relationship.setDestinationID(destinationID);
			relationship.setDestinationName(destinationName);
			relationship.setlowerValue(lower);
			relationship.setupperValue(upper);
	        System.out.println("		====getRelationships:Relationship:"+relationship.getID()+" lowerValure:"+relationship.getlowerValue() + "upperValure:"+relationship.getupperValue());

			String ID = version+"Composite"+sourceName+destinationName+"id";
			relationship.setID(ID);
		
			list.add(relationship);
		}
		if (node.attributeValue("aggregation")!=null && node.attributeValue("aggregation").equals("shared")) {
	        System.out.println("		====getRelationships:getRelationshipsOneVersion: �ۺ�");
			Element parent = node.getParent();
			String sourceName = parent.attributeValue("name");
			String sourceID = parent.attributeValue("id");
			RelationType relationship = new RelationType();
			relationship.setType("Shared");
			relationship.setVersion(version);
			String destinationID = node.attributeValue("type");
	        String destinationName =  node.attributeValue("name");
	        System.out.println("		====getRelationships: �ۺ�   source "+sourceName+"	des: "+destinationName);
	        Element lowerElement =node.element("lowerValue");// ��ȡ�ӽڵ�
	        Element upperElement =node.element("upperValue");// ��ȡ�ӽڵ�
	        int lower = Integer.parseInt(lowerElement.attributeValue("value"));
	        int upper = Integer.parseInt(upperElement.attributeValue("value"));
			relationship.setlowerValue(lower);
			relationship.setupperValue(upper);
			relationship.setSourceID(sourceID);
			relationship.setSourceName(sourceName);
			relationship.setDestinationID(destinationID);
			relationship.setDestinationName(destinationName);
//	        System.out.println("		====getRelationships:Relationship:"+relationship.getID()+" lowerValure:"+relationship.getlowerValue() + "upperValure:"+relationship.getupperValue());

			String ID = version+"Shared"+sourceName+destinationName+"id";
			relationship.setID(ID);
		
			list.add(relationship);
		}
		if ((node.attributeValue("aggregation")==null && node.attributeValue("association")!=null)&&(node.getName().equals("ownedEnd")==false)) {
	        System.out.println("		====getRelationships:getRelationshipsOneVersion: ����"+version+"  id: "+node.attributeValue("id"));
			Element parent = node.getParent();
			String sourceName = parent.attributeValue("name");
			String sourceID = parent.attributeValue("id");
			RelationType relationship = new RelationType();
			relationship.setType("Association");
			relationship.setVersion(version);
			String destinationID = node.attributeValue("type");
	        String destinationName =  node.attributeValue("name");
	        System.out.println("		====getRelationships: ����   source "+sourceName+"	des: "+destinationName);
	        Element lowerElement =node.element("lowerValue");// ��ȡ�ӽڵ�
	        Element upperElement =node.element("upperValue");// ��ȡ�ӽڵ�
	        int lower = Integer.parseInt(lowerElement.attributeValue("value"));
	        int upper = Integer.parseInt(upperElement.attributeValue("value"));
			relationship.setlowerValue(lower);
			relationship.setupperValue(upper);
			relationship.setSourceID(sourceID);
			relationship.setSourceName(sourceName);
			relationship.setDestinationID(destinationID);
			relationship.setDestinationName(destinationName);
//	        System.out.println("		====getRelationships:Relationship:"+relationship.getID()+" lowerValure:"+relationship.getlowerValue() + "upperValure:"+relationship.getupperValue());

			String ID = version+"Association"+sourceName+destinationName+"id";
			relationship.setID(ID);
		
			list.add(relationship);
		}
	    // �ݹ������ǰ�ڵ����е��ӽڵ�
	    List<Element> listElement = node.elements();// ����һ���ӽڵ��list
	    for (Element e : listElement) {// ��������һ���ӽڵ�
	    	getRelationships.getRelationshipsOneVersion(VersionsClassList,list,e,version);// �ݹ�
	    }
		return list;
	}
	//��ָ��id������
	private static String getClassNameByID(Map<String, List<ClassType>> VersionsClassList,String version,String ID) {
	List<ClassType> list= VersionsClassList.get(version);
	for(ClassType class1:list) {
		if(class1.getclassID().equals(ID))
			return class1.getclassName();
	}
	return "Cannot find";
	}

}
