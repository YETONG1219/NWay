package com.nway.handlers;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import com.nway.utils.ClassType;
import com.nway.utils.ElementType;
import com.nway.utils.PathType;
import com.nway.utils.RelationType;
import com.nway.views.MergeView;

public class createClassView {
    public static void main(String[] selectedVersions) throws Exception {
		Map<PathType,List<ElementType>> map= PathMerge.main(selectedVersions);

    	String newVersionName = "version_merge";//�����ɵİ汾��
    	int flag =1;
    	String projectPath = System.getProperty("user.dir");
  
    	String project=projectPath + "\\Models\\"+ newVersionName +".project";
    	String projectContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
    			"<projectDescription>\r\n" + 
    			"	<name>"+newVersionName+"</name>\r\n" + 
    			"	<comment></comment>\r\n" + 
    			"	<projects>\r\n" + 
    			"	</projects>\r\n" + 
    			"	<buildSpec>\r\n" + 
    			"	</buildSpec>\r\n" + 
    			"	<natures>\r\n" + 
    			"	</natures>\r\n" + 
    			"</projectDescription>";
    	writeFile(projectContent, project);
    	String di= projectPath + "\\Models\\" +newVersionName+".di";
    	String diContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
    			"<architecture:ArchitectureDescription xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:architecture=\"http://www.eclipse.org/papyrus/infra/core/architecture\" contextId=\"org.eclipse.papyrus.infra.services.edit.TypeContext\"/>\r\n" + 
    			"";
    	writeFile(diContent,di);
//    	readXML();
    	String XMLFileName=projectPath + "\\Models\\" +newVersionName+".uml";
    	String NotationFileName=projectPath + "\\Models\\" +newVersionName+ ".notation";


    	writeXMLM(newVersionName,XMLFileName, map);
        writeNotation(newVersionName,NotationFileName, map);
        writeRelationships(selectedVersions,newVersionName,XMLFileName,NotationFileName);
        writeXMLEnd(XMLFileName);
        writeNotationEnd(NotationFileName);
        

    }
private static void writeXMLEnd(String XMLFileName) {
		// TODO Auto-generated method stub
		String XMLEnd = "</uml:Model>\r\n";
	    writeFile_Add(XMLEnd,XMLFileName);

	}
private static void writeNotationEnd(String notationFileName) {
		// TODO Auto-generated method stub
	String notationEnd = "</notation:Diagram>\r\n";
	writeFile_Add(notationEnd,notationFileName);
	}
//    д���ļ�
    public static void writeFile(String content,String FileName)  {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter(FileName));
            out.write(content);
            out.close();
//            System.out.println("�ļ������ɹ���");
        } catch (IOException e) {
        }
    }
    //����ļ�
    public static void clearInfoForFile(String fileName) {
        File file =new File(fileName);
        try {
            if(!file.exists()) {
                file.createNewFile();
            }
            FileWriter fileWriter =new FileWriter(file);
            fileWriter.write("");
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//  д���ļ�-���б�����
  public static void writeFileByList(List<String> content,String FileName)  {
	  clearInfoForFile(FileName);//����ļ�
      try {
          BufferedWriter out =null;
          out = new BufferedWriter( new OutputStreamWriter(  
                  new FileOutputStream(FileName, true)));  
    	  for(String str:content) {
              out.write(str);
              out.write("\r\n");
    	  }
          out.close();
      } catch (IOException e) {
      }
  }
//  д���ļ�׷��
  public static void writeFile_Add(String content,String FileName)  {
      try {
          BufferedWriter out =null;
          out = new BufferedWriter( new OutputStreamWriter(  
                  new FileOutputStream(FileName, true)));  
          out.write(content);
          out.close();
//          System.out.println("�ļ�׷�ӳɹ���");
      } catch (IOException e) {
      }
  }

//  дxml
    public static void writeXMLM(String version, String fileName,Map<PathType,List<ElementType>> map) {
    	String head ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
    			"<uml:Model xmi:version=\"20131001\" xmlns:xmi=\"http://www.omg.org/spec/XMI/20131001\" xmlns:uml=\"http://www.eclipse.org/uml2/5.0.0/UML\" xmi:id=\"_sN_SkFFkEeuHS5D3vKMBTw\" name=\""+version+"\">\r\n" + 
    			"  <packageImport xmi:type=\"uml:PackageImport\" xmi:id=\"_sSpwIFFkEeuHS5D3vKMBTw\">\r\n" + 
    			"    <importedPackage xmi:type=\"uml:Model\" href=\"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#_0\"/>\r\n" + 
    			"  </packageImport>\r\n" ;
    	writeFile(head,fileName);
   	 for(PathType path:map.keySet()) {
			System.out.println("+++++++++++createClassView д�� ��"+PathType.getClassName(path));
			String packagedElementHead = "<packagedElement xmi:type=\"uml:Class\" xmi:id=\""+version+"class"+PathType.getClassName(path)+"id"+"\" name=\""+PathType.getClassName(path)+"\">\r\n";
			writeFile_Add(packagedElementHead,fileName);
			for (ElementType e:map.get(path)){
				System.out.println("		д��***"+e.gettype()+':'+e.getname()+"�汾��"+e.getversion());
				if(e.gettype().equals("Property")) {
					String ownedAttribute ="<ownedAttribute xmi:type=\"uml:Property\" xmi:id=\""+e.getname()+"id"+"\" name=\""+e.getname()+"\">\r\n" + 
							"      <type xmi:type=\"uml:PrimitiveType\" href=\"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#String\"/>\r\n" + 
							"    </ownedAttribute>\r\n";
					writeFile_Add(ownedAttribute,fileName);
				}
				if(e.gettype().equals("Operation")) {
					String ownedAttribute =" <ownedOperation xmi:type=\"uml:Operation\" xmi:id=\""+e.getname()+"id"+"\" name=\""+e.getname()+"\"/>\r\n";
					writeFile_Add(ownedAttribute,fileName);
				}
			}
			String packagedElementEnd =" </packagedElement>\r\n";
			writeFile_Add(packagedElementEnd,fileName);
   	 }
    }
//  дnotation
    public static void writeNotation(String version, String fileName,Map<PathType,List<ElementType>> map) {
    	String head ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
    			"<notation:Diagram xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:notation=\"http://www.eclipse.org/gmf/runtime/1.0.2/notation\" xmlns:style=\"http://www.eclipse.org/papyrus/infra/gmfdiag/style\" xmlns:uml=\"http://www.eclipse.org/uml2/5.0.0/UML\" xmi:id=\"_sOoy0FFkEeuHS5D3vKMBTw\" type=\"PapyrusUMLClassDiagram\" name=\"Class Diagram\" measurementUnit=\"Pixel\">\r\n" ;
    	writeFile(head,fileName);
    	int id=0;
   	 for(PathType path:map.keySet()) {
   		    id++;
			System.out.println("-----------createClassView д�� ��notation"+PathType.getClassName(path));
			String classHead = "  <children xmi:type=\"notation:Shape\" xmi:id=\""+version+"class"+PathType.getClassName(path)+"id"+"\" type=\"Class_Shape\">\r\n" + 
					"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_tEdnkFFkEeuHS5D"+id+"3vKMBTw\" type=\"Class_NameLabel\"/>\r\n" + 
					"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_tEdnkVFkEeuHS5D"+id+"3vKMBTw\" type=\"Class_FloatingNameLabel\">\r\n" + 
					"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_tEdnklFkEeuHS5D"+id+"3vKMBTw\" y=\"15\"/>\r\n" + 
					"    </children>\r\n";
			writeFile_Add(classHead,fileName);
			int pro=0;
			int oper=0;
			int rel=0;
			for (ElementType e:map.get(path)){
				if(e.gettype().equals("Property")) 
					pro++;
				if(e.gettype().equals("Operation")) 
					oper++;
				if(e.gettype().equals("Relationship")) 
					rel++;
			}
			String attributeHead =" <children xmi:type=\"notation:BasicCompartment\" xmi:id=\"_tEdnk1FkEe"+id+"uHS5D3vKMBTw\" type=\"Class_AttributeCompartment\">\r\n"; 
			writeFile_Add(attributeHead,fileName);

			for (ElementType e:map.get(path)){
				System.out.println("		д��***"+e.gettype()+':'+e.getname()+"�汾��"+e.getversion());
				if(e.gettype().equals("Property")) {
					String ownedAttribute =" <children xmi:type=\"notation:Shape\" xmi:id=\"_w9kAEFFkEe"+id+"uHS5D3vKMBTw\" type=\"Property_ClassAttributeLabel\">\r\n" + 
							"        <element xmi:type=\"uml:Property\" href=\""+version+".uml#"+e.getname()+"id"+"\"/>\r\n" + 
							"        <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_w9kAEVFkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
							"      </children>\r\n";
					writeFile_Add(ownedAttribute,fileName);
					id++;
					pro--;
					if(pro==0) {
						String attributeEnd = "      <styles xmi:type=\"notation:TitleStyle\" xmi:id=\"_tEdnlFFkEe"+id +"uHS5D3vKMBTw\"/>\r\n" + 
								"      <styles xmi:type=\"notation:SortingStyle\" xmi:id=\"_tEdnlVFkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
								"      <styles xmi:type=\"notation:FilteringStyle\" xmi:id=\"_tEdnllFkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
								"      <layoutConstraint xmi:type=\"notation:Bounds\" xmi:id=\"_tEdnl1FkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
								"    </children>\r\n";
						writeFile_Add(attributeEnd,fileName);
						String operationHead="<children xmi:type=\"notation:BasicCompartment\" xmi:id=\"_tEdnmFFkEe"+id+"uHS5D3vKMBTw\" type=\"Class_OperationCompartment\">\r\n";
						writeFile_Add(operationHead,fileName);
						if(oper==0) {
							String operationEnd ="      <styles xmi:type=\"notation:TitleStyle\" xmi:id=\"_tEdnmVFkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
									"      <styles xmi:type=\"notation:SortingStyle\" xmi:id=\"_tEdnmlFkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
									"      <styles xmi:type=\"notation:FilteringStyle\" xmi:id=\"_tEdnm1FkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
									"      <layoutConstraint xmi:type=\"notation:Bounds\" xmi:id=\"_tEdnnFFkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
									"    </children>\r\n";
							writeFile_Add(operationEnd,fileName);
						}
					}
				}

				if(e.gettype().equals("Operation")) {
					String ownedOperation ="      <children xmi:type=\"notation:Shape\" xmi:id=\"_6WwIwFF_EeuH"+id+"S5D3vKMBTw\" type=\"Operation_ClassOperationLabel\">\r\n" + 
							"        <element xmi:type=\"uml:Operation\" href=\""+version+".uml#"+e.getname()+"id"+"\"/>\r\n" + 
							"        <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_6WwIwVF_EeuHS"+id+"5D3vKMBTw\"/>\r\n" + 
							"      </children>\r\n";
					writeFile_Add(ownedOperation,fileName);
					id++;
					oper--;
					if(oper==0) {
						String operationEnd ="      <styles xmi:type=\"notation:TitleStyle\" xmi:id=\"_tEdnmVFkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
								"      <styles xmi:type=\"notation:SortingStyle\" xmi:id=\"_tEdnmlFkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
								"      <styles xmi:type=\"notation:FilteringStyle\" xmi:id=\"_tEdnm1FkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
								"      <layoutConstraint xmi:type=\"notation:Bounds\" xmi:id=\"_tEdnnFFkEe"+id+"uHS5D3vKMBTw\"/>\r\n" + 
								"    </children>\r\n";
						writeFile_Add(operationEnd,fileName);
					}
				}
			}
			String classEnd="    <children xmi:type=\"notation:BasicCompartment\" xmi:id=\"_qZueallh"+id+"EeuyqpbL3HXl_A\" type=\"Class_NestedClassifierCompartment\">\r\n" + 
					"      <styles xmi:type=\"notation:TitleStyle\" xmi:id=\"_qZuea1lhEeu"+id+"yqpbL3HXl_A\"/>\r\n" + 
					"      <styles xmi:type=\"notation:SortingStyle\" xmi:id=\"_qZuebFlhE"+id+"euyqpbL3HXl_A\"/>\r\n" + 
					"      <styles xmi:type=\"notation:FilteringStyle\" xmi:id=\"_qZuebVlhEe"+id+"uyqpbL3HXl_A\"/>\r\n" + 
					"      <layoutConstraint xmi:type=\"notation:Bounds\" xmi:id=\"_qZuebllhEe"+id+"uyqpbL3HXl_A\"/>\r\n" + 
					"    </children>\r\n" ;
			writeFile_Add(classEnd,fileName);
			String classEnd2="    <element xmi:type=\"uml:Class\" href=\""+version+".uml#"+version+"class"+PathType.getClassName(path)+"id"+"\"/>\r\n" + 
					"    <layoutConstraint xmi:type=\"notation:Bounds\" xmi:id=\"_qZktYVlhEeuyqpbL3HXl_A\" x=\"160\" y=\"260\" width=\"201\" height=\"141\"/>\r\n" + 
					"  </children>\r\n";
			writeFile_Add(classEnd2,fileName);

   	 }
   	 String notationEnd = " <styles xmi:type=\"notation:StringValueStyle\" xmi:id=\"_sOoy0VFkEeuHS5D3vKMBTw\" name=\"diagram_compatibility_version\" stringValue=\"1.4.0\"/>\r\n" + 
    			"  <styles xmi:type=\"notation:DiagramStyle\" xmi:id=\"_sOoy0lFkEeuHS5D3vKMBTw\"/>\r\n" + 
       			"  <styles xmi:type=\"style:PapyrusDiagramStyle\" xmi:id=\"_sOoy01FkEeuHS5D3vKMBTw\" diagramKindId=\"org.eclipse.papyrus.uml.diagram.class\">\r\n" + 
       			"    <owner xmi:type=\"uml:Model\" href=\""+version+".uml#_sN_SkFFkEeuHS5D3vKMBTw\"/>\r\n" + 
       			"  </styles>\r\n" + 
       			"  <element xmi:type=\"uml:Model\" href=\""+version+".uml#_sN_SkFFkEeuHS5D3vKMBTw\"/>\r\n";
       	writeFile_Add(notationEnd,fileName);
    }
  //дdependency��xml
    public static String addDependencyUML(RelationType relation,String newVersion) {
  	String sourceID = newVersion+"class"+relation.getSourceName()+"id";
  	String desID = newVersion+"class"+relation.getDestinationName()+"id";
  	String id = newVersion+"dependency"+relation.getSourceName()+relation.getDestinationName()+"id";
    	String addUML ="  <packagedElement xmi:type=\"uml:Dependency\" xmi:id=\""+id+"\" client=\""+sourceID+"\" supplier=\""+desID+"\"/>"; 
    	return addUML;
    }
    //дcomposite��xml
    public static String addCompositeUML(RelationType relation,String newVersion) {
  	String sourceID = newVersion+"class"+relation.getSourceName()+"id";
  	String desID = newVersion+"class"+relation.getDestinationName()+"id";
	String id = newVersion+"Composite"+relation.getSourceName()+relation.getDestinationName()+"id";
    String addUML ="<packagedElement xmi:type=\"uml:Association\" xmi:id=\""+id+"\" memberEnd=\""+"attribute"+id+" "+"ownedEnd"+id+"\">\r\n" + 
    		"    <eAnnotations xmi:type=\"ecore:EAnnotation\" xmi:id=\"_j3VD4WIeEeunV5LMEIMAqA\" source=\"org.eclipse.papyrus\">\r\n" + 
    		"      <details xmi:type=\"ecore:EStringToStringMapEntry\" xmi:id=\"_j3VD4mIeEeunV5LMEIMAqA\" key=\"nature\" value=\"UML_Nature\"/>\r\n" + 
    		"    </eAnnotations>\r\n" + 
    		"    <ownedEnd xmi:type=\"uml:Property\" xmi:id=\""+"ownedEnd"+id+"\" name=\""+relation.getSourceName()+"\" type=\""+sourceID+"\" association=\""+id+"\"/>\r\n" + 
    		"  </packagedElement>"; 
    return addUML;
    }
    //дShared�ۺϹ�ϵ��xml
    public static String addSharedUML(RelationType relation,String newVersion) {
  	String sourceID = newVersion+"class"+relation.getSourceName()+"id";
  	String desID = newVersion+"class"+relation.getDestinationName()+"id";
	String id = newVersion+"Shared"+relation.getSourceName()+relation.getDestinationName()+"id";
	String addUML = "<packagedElement xmi:type=\"uml:Association\" xmi:id=\""+id+"\" memberEnd=\""+"attribute"+id+" "+"ownedEnd"+id+"\">\r\n" + 
			"    <eAnnotations xmi:type=\"ecore:EAnnotation\" xmi:id=\"_FwYhoGIiEeunV5LMEIMAqA\" source=\"org.eclipse.papyrus\">\r\n" + 
			"      <details xmi:type=\"ecore:EStringToStringMapEntry\" xmi:id=\"_FwYhoWIiEeunV5LMEIMAqA\" key=\"nature\" value=\"UML_Nature\"/>\r\n" + 
			"    </eAnnotations>\r\n" + 
			"    <ownedEnd xmi:type=\"uml:Property\" xmi:id=\""+"ownedEnd"+id+"\" name=\""+relation.getSourceName()+"\" type=\""+sourceID+"\" association=\""+id+"\"/>\r\n" + 
			"  </packagedElement>";
    return addUML;
    }
    //дAssociation������ϵ��xml
    public static String addAssociationUML(RelationType relation,String newVersion) {
  	String sourceID = newVersion+"class"+relation.getSourceName()+"id";
  	String desID = newVersion+"class"+relation.getDestinationName()+"id";
	String id = newVersion+"Association"+relation.getSourceName()+relation.getDestinationName()+"id";
	String addUML = "<packagedElement xmi:type=\"uml:Association\" xmi:id=\""+id+"\" memberEnd=\""+"attribute"+id+" "+"ownedEnd"+id+"\">\r\n" + 
			"    <eAnnotations xmi:type=\"ecore:EAnnotation\" xmi:id=\"_3jnEcWIiEeunV5LMEIMAqA\" source=\"org.eclipse.papyrus\">\r\n" + 
			"      <details xmi:type=\"ecore:EStringToStringMapEntry\" xmi:id=\"_3jnEcmIiEeunV5LMEIMAqA\" key=\"nature\" value=\"UML_Nature\"/>\r\n" + 
			"    </eAnnotations>\r\n" + 
			"    <ownedEnd xmi:type=\"uml:Property\" xmi:id=\""+"ownedEnd"+id+"\" name=\""+relation.getSourceName()+"\" type=\""+sourceID+"\" association=\""+id+"\"/>\r\n" + 
			"  </packagedElement>";
    return addUML;
    }
  //дdependency��notation
    public static String addDependencyNotation(RelationType relation,String newVersion) {
  		String sourceID = newVersion+"class"+relation.getSourceName()+"id";
  		String desID = newVersion+"class"+relation.getDestinationName()+"id";
  		String id = newVersion+"dependency"+relation.getSourceName()+relation.getDestinationName()+"id";
  		String addNotation = "	   <edges xmi:type=\"notation:Connector\" xmi:id=\""+id+"\" type=\"Dependency_Edge\" source=\""+sourceID+"\" target=\""+desID+"\">\r\n" + 
  	  		"	    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_sZjF8GIFEeunV5LMEIMAqA\" type=\"Dependency_NameLabel\">\r\n" + 
  	  		"	      <styles xmi:type=\"notation:BooleanValueStyle\" xmi:id=\"_wYBGoGIFEeunV5LMEIMAqA\" name=\"IS_UPDATED_POSITION\" booleanValue=\"true\"/>\r\n" + 
  	  		"	      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_sZjF8WIFEeunV5LMEIMAqA\" y=\"40\"/>\r\n" + 
  	  		"	    </children>\r\n" + 
  	  		"	    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_sZjF8mIFEeunV5LMEIMAqA\" type=\"Dependency_StereotypeLabel\">\r\n" + 
  	  		"	      <styles xmi:type=\"notation:BooleanValueStyle\" xmi:id=\"_wYJCcGIFEeunV5LMEIMAqA\" name=\"IS_UPDATED_POSITION\" booleanValue=\"true\"/>\r\n" + 
  	  		"	      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_sZjF82IFEeunV5LMEIMAqA\" y=\"60\"/>\r\n" + 
  	  		"	    </children>\r\n" + 
  	  		"	    <styles xmi:type=\"notation:FontStyle\" xmi:id=\"_sZie4WIFEeunV5LMEIMAqA\"/>\r\n" + 
  	  		"	    <element xmi:type=\"uml:Dependency\" href=\""+newVersion+".uml#"+id+"\"/>\r\n" + 
  	  		"	    <bendpoints xmi:type=\"notation:RelativeBendpoints\" xmi:id=\"_sZie4mIFEeunV5LMEIMAqA\" points=\"[400, 160, -643984, -643984]$[361, 160, -643984, -643984]\"/>\r\n" + 
  	  		"	    <sourceAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_sZ8ukGIFEeunV5LMEIMAqA\" id=\"(0.0,0.45714285714285713)\"/>\r\n" + 
  	  		"	    <targetAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_sZ8ukWIFEeunV5LMEIMAqA\" id=\"(1.0,0.425531914893617)\"/>\r\n" + 
  	  		"	  </edges>\r\n";
  		return addNotation;

    }
    //дGeneralization��notation
    public static String addGeneralizationNotation(RelationType relation,String newVersion) {
  		String sourceID = newVersion+"class"+relation.getSourceName()+"id";
  		String desID = newVersion+"class"+relation.getDestinationName()+"id";
  		String id = newVersion+"Generalization"+relation.getSourceName()+relation.getDestinationName()+"id";
  		String addNotation="<edges xmi:type=\"notation:Connector\" xmi:id=\""+id+"\" type=\"Generalization_Edge\" source=\""+sourceID+"\" target=\""+desID+"\">\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_Ip_N0GHnEeunV5LMEIMAqA\" type=\"Generalization_StereotypeLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_Ip_N0WHnEeunV5LMEIMAqA\" y=\"40\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <styles xmi:type=\"notation:FontStyle\" xmi:id=\"_Ip-mwWHnEeunV5LMEIMAqA\"/>\r\n" + 
  				"    <element xmi:type=\"uml:Generalization\" href=\""+newVersion+".uml#"+id+"\"/>\r\n" + 
  				"    <bendpoints xmi:type=\"notation:RelativeBendpoints\" xmi:id=\"_Ip-mwmHnEeunV5LMEIMAqA\" points=\"[320, 100, -643984, -643984]$[460, 100, -643984, -643984]\"/>\r\n" + 
  				"    <sourceAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_IqK0AGHnEeunV5LMEIMAqA\" id=\"(1.0,0.6)\"/>\r\n" + 
  				"    <targetAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_IqK0AWHnEeunV5LMEIMAqA\" id=\"(0.0,0.6)\"/>\r\n" + 
  				"  </edges>\r\n";
  		return addNotation;
    }
    //дComposite��notation
    public static String addCompositeNotation(RelationType relation,String newVersion) {
  		String sourceID = newVersion+"class"+relation.getSourceName()+"id";
  		String desID = newVersion+"class"+relation.getDestinationName()+"id";
  		String id = newVersion+"Composite"+relation.getSourceName()+relation.getDestinationName()+"id";
  		String addNotation="<edges xmi:type=\"notation:Connector\" xmi:id=\""+id+"\" type=\"Association_Edge\" source=\""+sourceID+"\" target=\""+desID+"\">\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_j3YHM2IeEeunV5LMEIMAqA\" type=\"Association_StereotypeLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_j3YHNGIeEeunV5LMEIMAqA\" y=\"-20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_j3YHNWIeEeunV5LMEIMAqA\" type=\"Association_NameLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_j3YHNmIeEeunV5LMEIMAqA\" y=\"20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_j3YHN2IeEeunV5LMEIMAqA\" type=\"Association_TargetRoleLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_j3YHOGIeEeunV5LMEIMAqA\" y=\"-20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_j3YHOWIeEeunV5LMEIMAqA\" type=\"Association_SourceRoleLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_j3YHOmIeEeunV5LMEIMAqA\" y=\"20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_j3YHO2IeEeunV5LMEIMAqA\" type=\"Association_SourceMultiplicityLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_j3YHPGIeEeunV5LMEIMAqA\" y=\"20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_j3YHPWIeEeunV5LMEIMAqA\" type=\"Association_TargetMultiplicityLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_j3YHPmIeEeunV5LMEIMAqA\" y=\"-20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <styles xmi:type=\"notation:FontStyle\" xmi:id=\"_j3YHMWIeEeunV5LMEIMAqA\"/>\r\n" + 
  				"    <element xmi:type=\"uml:Association\" href=\""+newVersion+".uml#"+id+"\"/>\r\n" + 
  				"    <bendpoints xmi:type=\"notation:RelativeBendpoints\" xmi:id=\"_j3YHMmIeEeunV5LMEIMAqA\" points=\"[360, 200, -643984, -643984]$[520, 200, -643984, -643984]\"/>\r\n" + 
  				"    <sourceAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_j3h4MGIeEeunV5LMEIMAqA\" id=\"(1.0,0.4)\"/>\r\n" + 
  				"    <targetAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_j3h4MWIeEeunV5LMEIMAqA\" id=\"(0.0,0.4)\"/>\r\n" + 
  				"  </edges>\r\n";
  		return addNotation;
    }
    //дShared�ۺϹ�ϵ��notation
    public static String addSharedNotation(RelationType relation,String newVersion) {
  		String sourceID = newVersion+"class"+relation.getSourceName()+"id";
  		String desID = newVersion+"class"+relation.getDestinationName()+"id";
  		String id = newVersion+"Shared"+relation.getSourceName()+relation.getDestinationName()+"id";
  		String addNotation= " <edges xmi:type=\"notation:Connector\" xmi:id=\""+id+"\" type=\"Association_Edge\" source=\""+sourceID+"\" target=\""+desID+"\">\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_zupIk2IjEeunV5LMEIMAqA\" type=\"Association_StereotypeLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_zupIlGIjEeunV5LMEIMAqA\" y=\"-20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_zupIlWIjEeunV5LMEIMAqA\" type=\"Association_NameLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_zupvoGIjEeunV5LMEIMAqA\" y=\"20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_zupvoWIjEeunV5LMEIMAqA\" type=\"Association_TargetRoleLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_zupvomIjEeunV5LMEIMAqA\" y=\"-20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_zupvo2IjEeunV5LMEIMAqA\" type=\"Association_SourceRoleLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_zupvpGIjEeunV5LMEIMAqA\" y=\"20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_zupvpWIjEeunV5LMEIMAqA\" type=\"Association_SourceMultiplicityLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_zupvpmIjEeunV5LMEIMAqA\" y=\"20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_zupvp2IjEeunV5LMEIMAqA\" type=\"Association_TargetMultiplicityLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_zupvqGIjEeunV5LMEIMAqA\" y=\"-20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <styles xmi:type=\"notation:FontStyle\" xmi:id=\"_zupIkWIjEeunV5LMEIMAqA\"/>\r\n" + 
  				"    <element xmi:type=\"uml:Association\" href=\""+newVersion+".uml#"+id+"\"/>\r\n" + 
  				"    <bendpoints xmi:type=\"notation:RelativeBendpoints\" xmi:id=\"_zupIkmIjEeunV5LMEIMAqA\" points=\"[360, 220, -643984, -643984]$[520, 220, -643984, -643984]\"/>\r\n" + 
  				"    <sourceAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_zu0uwGIjEeunV5LMEIMAqA\" id=\"(1.0,0.6)\"/>\r\n" + 
  				"    <targetAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_zu0uwWIjEeunV5LMEIMAqA\" id=\"(0.0,0.6)\"/>\r\n" + 
  				"  </edges>";
  		return addNotation;
    }
    //дAssociation������ϵ��notation
    public static String addAssociationNotation(RelationType relation,String newVersion) {
  		String sourceID = newVersion+"class"+relation.getSourceName()+"id";
  		String desID = newVersion+"class"+relation.getDestinationName()+"id";
  		String id = newVersion+"Association"+relation.getSourceName()+relation.getDestinationName()+"id";
  		String addNotation=" <edges xmi:type=\"notation:Connector\" xmi:id=\""+id+"\" type=\"Association_Edge\" source=\""+sourceID+"\" target=\""+desID+"\">\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_3juZMGIiEeunV5LMEIMAqA\" type=\"Association_StereotypeLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_3juZMWIiEeunV5LMEIMAqA\" y=\"-20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_3juZMmIiEeunV5LMEIMAqA\" type=\"Association_NameLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_3juZM2IiEeunV5LMEIMAqA\" y=\"20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_3juZNGIiEeunV5LMEIMAqA\" type=\"Association_TargetRoleLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_3juZNWIiEeunV5LMEIMAqA\" y=\"-20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_3juZNmIiEeunV5LMEIMAqA\" type=\"Association_SourceRoleLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_3juZN2IiEeunV5LMEIMAqA\" y=\"20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_3juZOGIiEeunV5LMEIMAqA\" type=\"Association_SourceMultiplicityLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_3juZOWIiEeunV5LMEIMAqA\" y=\"20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <children xmi:type=\"notation:DecorationNode\" xmi:id=\"_3juZOmIiEeunV5LMEIMAqA\" type=\"Association_TargetMultiplicityLabel\">\r\n" + 
  				"      <layoutConstraint xmi:type=\"notation:Location\" xmi:id=\"_3juZO2IiEeunV5LMEIMAqA\" y=\"-20\"/>\r\n" + 
  				"    </children>\r\n" + 
  				"    <styles xmi:type=\"notation:FontStyle\" xmi:id=\"_3jtyIWIiEeunV5LMEIMAqA\"/>\r\n" + 
  				"    <element xmi:type=\"uml:Association\" href=\""+newVersion+".uml#"+id+"\"/>\r\n" + 
  				"    <bendpoints xmi:type=\"notation:RelativeBendpoints\" xmi:id=\"_3jtyImIiEeunV5LMEIMAqA\" points=\"[360, 200, -643984, -643984]$[520, 200, -643984, -643984]\"/>\r\n" + 
  				"    <sourceAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_3j_e8GIiEeunV5LMEIMAqA\" id=\"(1.0,0.4)\"/>\r\n" + 
  				"    <targetAnchor xmi:type=\"notation:IdentityAnchor\" xmi:id=\"_3j_e8WIiEeunV5LMEIMAqA\" id=\"(0.0,0.4)\"/>\r\n" + 
  				"  </edges>\r\n";
  		
  		return addNotation;
    }
//д�������ļ��Ĺ�����ϵ�����ļ�
    public static void writeRelationships(String[] selectedVersions,String newVersion, String UMLFileName,String NotationFileName) throws DocumentException {
		Map<String, List<RelationType>> VersionsRelationshipsList =getRelationships.main(selectedVersions);
		for(String version:VersionsRelationshipsList.keySet()) {
	           System.out.println("====CreateClassView: getRelationships----�汾"+version+"��relationsip���б�");
	           List<RelationType> OneVersionRList = VersionsRelationshipsList.get(version);
	           for(RelationType R:OneVersionRList) {
		           System.out.println("		version: "+R.getVersion());
		           System.out.println("		ID: "+R.getID());
		           System.out.println("		type: "+R.getType());
		           System.out.println("		source: "+R.getSourceName()+"	des: "+R.getDestinationName());
		           if(R.getType().equals("uml:Dependency")) {
		        	   String DependencyUML = addDependencyUML(R,newVersion);
		               writeFile_Add(DependencyUML,UMLFileName);
		               String DependencyNotation = addDependencyNotation(R,newVersion);
		               writeFile_Add(DependencyNotation,NotationFileName);
		           }
		           if(R.getType().equals("uml:Generalization")) {
			        System.out.println("====CreateClassView writeRelationships: Generalization");
		        	String  addUMLGeneralization = "    <generalization xmi:type=\"uml:Generalization\" xmi:id=\""+newVersion+"Generalization"+R.getSourceName()+R.getDestinationName()+"id"+"\" general=\""+newVersion+"class"+R.getDestinationName()+"id"+"\"/>"; 
		        	List <String> writeList = new ArrayList<String>();//��дuml�ļ��õ�list
		    		ArrayList<String> readList = MergeView.getTxt(UMLFileName);//��ȡuml�ļ��õ�list
		    		//classLine����Ҫ���뵽���uml��
		    		String classLine = "<packagedElement xmi:type=\"uml:Class\" xmi:id=\""+newVersion+"class"+R.getSourceName()+"id"+"\" name=\""+R.getSourceName()+"\">";
//			        System.out.println("====CreateClassView writeRelationships: Generalization�Ƚ�����һ�� classLine:\r\n"+classLine);
		    		for(String item:readList) {
//				        System.out.println("			�Ƚ�����һ�� readLine:   "+item);
		    			writeList.add(item);
		    			if(item.equals(classLine))
			    			writeList.add(addUMLGeneralization);//���ӷ�����ϵ
		    		}
		    		writeFileByList(writeList ,UMLFileName);//��д�ļ�
		    		String GeneralizationNotation = addGeneralizationNotation(R,newVersion);
		            writeFile_Add(GeneralizationNotation,NotationFileName);
		           }
		           if(R.getType().equals("Composite")) {
		        	   System.out.println("====CreateClassView writeRelationships: Composite");
		         		String id = newVersion+"Composite"+R.getSourceName()+R.getDestinationName()+"id";

		        	   //��������������Ϊ���Ե���Ϲ�ϵ��source��
			        	String  addUMLCompositeInSourceClass1="	<ownedAttribute xmi:type=\"uml:Property\" xmi:id=\""+"attribute"+id+"\" name=\""+R.getDestinationName()+"\" type=\""+newVersion+"class"+R.getDestinationName()+"id"+"\" aggregation=\"composite\" association=\""+id+"\">"; 
			        	String  addUMLCompositeInSourceClass2="      <lowerValue xmi:type=\"uml:LiteralUnlimitedNatural\" xmi:id=\"_j3VD5GIeEeunV5LMEIMAqA\" value=\""+R.getlowerValue()+"\"/>" ;
			        	String  addUMLCompositeInSourceClass3="      <upperValue xmi:type=\"uml:LiteralUnlimitedNatural\" xmi:id=\"_j3Vq8GIeEeunV5LMEIMAqA\" value=\""+R.getupperValue()+"\"/>";
			        	String  addUMLCompositeInSourceClass4="    </ownedAttribute>"; 
			        	List <String> writeList = new ArrayList<String>();//��дuml�ļ��õ�list
			    		ArrayList<String> readList = MergeView.getTxt(UMLFileName);//��ȡuml�ļ��õ�list
			    		//classLine����Ҫ���뵽���uml��
			    		String classLine = "<packagedElement xmi:type=\"uml:Class\" xmi:id=\""+newVersion+"class"+R.getSourceName()+"id"+"\" name=\""+R.getSourceName()+"\">";
//				        System.out.println("====CreateClassView writeRelationships: Generalization�Ƚ�����һ�� classLine:\r\n"+classLine);
			    		for(String item:readList) {
//					        System.out.println("			�Ƚ�����һ�� readLine:   "+item);
			    			writeList.add(item);
			    			if(item.equals(classLine)) {
						        System.out.println("====CreateClassView writeRelationships: composite �ҵ�Դ");
				    			writeList.add(addUMLCompositeInSourceClass1);//������Ϲ�ϵ��һ��
			    				writeList.add(addUMLCompositeInSourceClass2);//���ӷ�����ϵ�ڶ���
			    				writeList.add(addUMLCompositeInSourceClass3);//���ӷ�����ϵ������
			    				writeList.add(addUMLCompositeInSourceClass4);//���ӷ�����ϵ������
			    				}
			    		}
			    		writeFileByList(writeList ,UMLFileName);//��д�ļ�
			    		//����packagedElement xmi:type="uml:Association"
			    		String CompositeUMLPackagement=addCompositeUML(R,newVersion);
			            writeFile_Add(CompositeUMLPackagement,UMLFileName);

			    		String CompositeNotation = addCompositeNotation(R,newVersion);
			            writeFile_Add(CompositeNotation,NotationFileName);
		           }
		           if(R.getType().equals("Shared")) {
		        	    System.out.println("====CreateClassView writeRelationships: Shared");
		         		String id = newVersion+"Shared"+R.getSourceName()+R.getDestinationName()+"id";

		        	    //��������������Ϊ���Ե���Ϲ�ϵ��source��
		         		String addUMLSharedInSourceClass1="<ownedAttribute xmi:type=\"uml:Property\" xmi:id=\""+"attribute"+id+"\" name=\""+R.getDestinationName()+"\" type=\""+newVersion+"class"+R.getDestinationName()+"id"+"\" aggregation=\"shared\" association=\""+id+"\">";
		         		String addUMLSharedInSourceClass2="      <lowerValue xmi:type=\"uml:LiteralUnlimitedNatural\" xmi:id=\"_FwYho2IiEeunV5LMEIMAqA\" value=\""+R.getlowerValue()+"\"/>";
		         		String addUMLSharedInSourceClass3="      <upperValue xmi:type=\"uml:LiteralUnlimitedNatural\" xmi:id=\"_FwYhpGIiEeunV5LMEIMAqA\" value=\""+R.getupperValue()+"\"/>";
		         		String addUMLSharedInSourceClass4="    </ownedAttribute>";
		         		
			        	List <String> writeList = new ArrayList<String>();//��дuml�ļ��õ�list
			    		ArrayList<String> readList = MergeView.getTxt(UMLFileName);//��ȡuml�ļ��õ�list
			    		//classLine����Ҫ���뵽���uml��
			    		String classLine = "<packagedElement xmi:type=\"uml:Class\" xmi:id=\""+newVersion+"class"+R.getSourceName()+"id"+"\" name=\""+R.getSourceName()+"\">";
//				        System.out.println("====CreateClassView writeRelationships: Generalization�Ƚ�����һ�� classLine:\r\n"+classLine);
			    		for(String item:readList) {
//					        System.out.println("			�Ƚ�����һ�� readLine:   "+item);
			    			writeList.add(item);
			    			if(item.equals(classLine)) {
						        System.out.println("====CreateClassView writeRelationships: composite �ҵ�Դ");
				    			writeList.add(addUMLSharedInSourceClass1);//���ӾۺϹ�ϵ��һ��
			    				writeList.add(addUMLSharedInSourceClass2);//���ӾۺϹ�ϵ�ڶ���
			    				writeList.add(addUMLSharedInSourceClass3);//���ӾۺϹ�ϵ������
			    				writeList.add(addUMLSharedInSourceClass4);//���ӾۺϹ�ϵ������
			    				}
			    		}
			    		writeFileByList(writeList ,UMLFileName);//��д�ļ�
			    		//����packagedElement xmi:type="uml:Association"
			    		String SharedUMLPackagement=addSharedUML(R,newVersion);
			            writeFile_Add(SharedUMLPackagement,UMLFileName);

			    		String SharedNotation = addSharedNotation(R,newVersion);
			            writeFile_Add(SharedNotation,NotationFileName);
		           }
		           if(R.getType().equals("Association")) {
		        	    System.out.println("====CreateClassView writeRelationships: Association");
		         		String id = newVersion+"Association"+R.getSourceName()+R.getDestinationName()+"id";
		         		 //��������������Ϊ���Ե���Ϲ�ϵ��source��
		         		String addUMLAssociationInSourceClass1="<ownedAttribute xmi:type=\"uml:Property\" xmi:id=\""+"attribute"+id+"\" name=\""+R.getDestinationName()+"\" type=\""+newVersion+"class"+R.getDestinationName()+"id"+"\" association=\""+id+"\">";
		         		String addUMLAssociationInSourceClass2="      <lowerValue xmi:type=\"uml:LiteralUnlimitedNatural\" xmi:id=\"_3jnrgGIiEeunV5LMEIMAqA\" value=\""+R.getlowerValue()+"\"/>";
		         		String addUMLAssociationInSourceClass3="      <upperValue xmi:type=\"uml:LiteralUnlimitedNatural\" xmi:id=\"_3jnrgWIiEeunV5LMEIMAqA\" value=\""+R.getupperValue()+"\"/>"; 
		         		String addUMLAssociationInSourceClass4="    </ownedAttribute>";

			        	List <String> writeList = new ArrayList<String>();//��дuml�ļ��õ�list
			    		ArrayList<String> readList = MergeView.getTxt(UMLFileName);//��ȡuml�ļ��õ�list
			    		//classLine����Ҫ���뵽���uml��
			    		String classLine = "<packagedElement xmi:type=\"uml:Class\" xmi:id=\""+newVersion+"class"+R.getSourceName()+"id"+"\" name=\""+R.getSourceName()+"\">";
//				        System.out.println("====CreateClassView writeRelationships: Generalization�Ƚ�����һ�� classLine:\r\n"+classLine);
			    		for(String item:readList) {
//					        System.out.println("			�Ƚ�����һ�� readLine:   "+item);
			    			writeList.add(item);
			    			if(item.equals(classLine)) {
						        System.out.println("====CreateClassView writeRelationships: Association �ҵ�Դ");
				    			writeList.add(addUMLAssociationInSourceClass1);//���ӹ�����ϵ��һ��
			    				writeList.add(addUMLAssociationInSourceClass2);//���ӹ�����ϵ�ڶ���
			    				writeList.add(addUMLAssociationInSourceClass3);//���ӹ�����ϵ������
			    				writeList.add(addUMLAssociationInSourceClass4);//���ӹ�����ϵ������
			    				}
			    		}
			    		writeFileByList(writeList ,UMLFileName);//��д�ļ�
			    		//����packagedElement xmi:type="uml:Association"
			    		String AssociationUMLPackagement=addAssociationUML(R,newVersion);
			            writeFile_Add(AssociationUMLPackagement,UMLFileName);

			    		String AssociationNotation = addAssociationNotation(R,newVersion);
			            writeFile_Add(AssociationNotation,NotationFileName);
		           }
	           }
	           
    }
   }

}




