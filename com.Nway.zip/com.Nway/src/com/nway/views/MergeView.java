package com.nway.views;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;


import javax.inject.Inject;



import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;

import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.nway.handlers.PathMerge;
import com.nway.handlers.createClassView;

import Graphviz.test;

import org.dom4j.DocumentException;

public class MergeView extends ViewPart {
	public static final String ID = "com.nway.views.MergeView";

	@Inject IWorkbench workbench;


	@Override
	public void createPartControl(Composite parent) {
		todo(parent);
	}
	public void todo(Composite parent) {

        TabFolder tabFolder = new TabFolder(parent,SWT.BORDER);

        TabItem tabItem1 = new TabItem(tabFolder,SWT.NONE);
        tabItem1.setText("N Way Model Merge");

        Composite compsoite1 = new Composite(tabFolder,SWT.NONE|SWT.V_SCROLL);
        tabItem1.setControl(compsoite1);

        String projectPath = System.getProperty("user.dir");
		String file = new String(projectPath+"\\Models\\version_info.txt");
		String filer = new String(projectPath+"\\Models\\version_r.txt");
		ArrayList<String> readList = getTxt(file);

		final Display display=Display.getDefault();
    	Image image = new Image(display,projectPath+"\\Models\\pic\\test.png");
        GridData gridA = new GridData();
        gridA.horizontalIndent = 15;
        gridA.widthHint = 480;
        gridA.heightHint = 410;
        gridA.horizontalSpan = 4;
        gridA.verticalIndent = 15;
        Label l = new Label(compsoite1, 0);
        l.setText("Existing Versions");
    	Canvas canvas = new Canvas(compsoite1, SWT.BORDER);
    	canvas.setLayoutData(gridA);
    	canvas.addPaintListener(new PaintListener() {
    	            public void paintControl(PaintEvent e) {
    	                if(image!=null)
    	                    e.gc.drawImage(image, 0, 0);
    	            }
    	        });
    	canvas.redraw();
        GridLayout layout = new GridLayout();
        layout.numColumns = 1;
        compsoite1.setLayout(layout);
        
        
        Group tableGroup = new Group(compsoite1,SWT.V_SCROLL);
        tableGroup.setText("Select Versions to Merge");
        GridData gd = new GridData(GridData.FILL_BOTH);
        gd.heightHint = 200;
        tableGroup.setLayoutData(gd);
        tableGroup.setLayout(new GridLayout(2,false));
        {    //����һ����ѡ�ģ��б߽�ģ�һ��ȫѡ�ı���
           Table table = new Table(tableGroup, SWT.CHECK | SWT.BORDER | SWT.MULTI |SWT.V_SCROLL);
            table.setHeaderVisible(true);//���ñ�ͷ�ɼ�
            table.setLinesVisible(true);//���������ɼ�
//            table.setLayoutData(new GridData(GridData.FILL_BOTH));
            GridData gridData = new GridData(GridData.FILL_BOTH);
            gridData.horizontalAlignment=SWT.FILL;//ˮƽ���
            gridData.horizontalSpan=2;
            table.setLayoutData(gridData);
            table.setSize(150, 150);

            TableColumn column1 = new TableColumn(table,SWT.NULL);
            column1.setText("Version");
            column1.pack();
            column1.setWidth(150);

			for(int i=0;i<readList.size();i++) {
				TableItem  item = new TableItem(table, SWT.NONE);
	            item.setText(readList.toArray()[i].toString());
			}
			
			GridData gridDatac=new GridData();
			gridDatac.horizontalSpan=2;//����ˮƽ��Խ2����Ԫ��
			gridDatac.horizontalAlignment=SWT.FILL;//ˮƽ���

			Boolean check = false;
			Button checkBox = new Button(tableGroup,SWT.CHECK);
			checkBox.setText("Automatic conflict handling");
			checkBox.setLayoutData(gridDatac);
			checkBox.addSelectionListener(new SelectionAdapter() {
			    @Override
			    public void widgetSelected(SelectionEvent event) {
			        if (event.detail == SWT.CHECK) {
			            // Now what should I do here to get
			            // Whether it is a checked event or unchecked event.
			        }
			    }
			});
			Button btnShow = new Button(tableGroup, 1);
			
    		btnShow.setText("Set Priorities");
    		btnShow.addSelectionListener(new SelectionAdapter() {
    			public void widgetSelected(SelectionEvent e) {

    				Display display = Display.getDefault();
    				final Shell shell = new Shell(display);
    				shell.setSize(400, 300);
    				shell.setText("Set Priorities");
    				//shell.setLayout(new FillLayout(SWT.VERTICAL));	
    									
    				final Text content = new Text(shell, SWT.WRAP|SWT.V_SCROLL);
    												// �����ı��򣬿��Զ����� | ��ֱ������
    				content.setBounds(10, 8, 200, 200);
    												// ��x, y, width, height��
					int selectedCount =0;
    				for(int i=0; i<table.getItemCount();i++ ) {
    					if(table.getItem(i).getChecked()==true) 
    						selectedCount++;
    				}
    				
					String[] selectedVersions = new String [selectedCount];
					String[] selectedVersions_short = new String [selectedCount];
					
					String versions = "";
					int index = 0;
    				for(int i=0; i<table.getItemCount();i++ ) {
    					if(table.getItem(i).getChecked()==true) {
    						selectedVersions[index]=table.getItem(i).toString();
    						selectedVersions_short[index] = selectedVersions[index].substring(selectedVersions[index].indexOf("{")+1,selectedVersions[index].indexOf("}"));
    						System.out.println("ѡ��������ȼ���" + selectedVersions[index].substring(selectedVersions[index].indexOf("{")+1,selectedVersions[index].indexOf("}")));
    						index++;}
    						}
    				if (index==0)
    					content.setText("Please select versions first!");
    				else {
 
    				for(int i=0; i<selectedVersions_short.length;i++ ) {
    					if (i==selectedVersions_short.length-1)
    					versions= versions + selectedVersions_short[i]+":";
    					else
    					versions= versions + selectedVersions_short[i]+":\r\n";
    						}
    				content.setText(versions);
    				}
    				// ȫѡ��ť
    				Button selectAll = new Button(shell, SWT.CENTER);
    				selectAll.setText("OK");
    				selectAll.setBounds(5, 225, 80, 25);
    												// ��x, y, width, height��
    				selectAll.addSelectionListener(new SelectionAdapter() {
    					public void widgetSelected(SelectionEvent e){
    						// ѡ�������ı�
    						try {
    							String projectPath = System.getProperty("user.dir");
    						    File dir = new File(projectPath + "\\Models");    // ��ȡĿ¼��dir����Ӧ��File����
    						    File file1 = new File(dir, "priority.txt");
    						    file1.createNewFile();
    						} catch (IOException e1) {
    						    e1.printStackTrace();
    						}
    						String priorities = content.getText();
    						System.out.println("����ǣ�"+ priorities);
    						setTxt1(projectPath + "\\Models\\priority.txt", priorities);
    					}
    				});
    				 
    				 
    				shell.layout();
    				shell.open();
  
    			}
    		});
			

    		
    		Button btnselect = new Button(tableGroup, 1);
    		btnselect.setText("Merge Selected Versions");
    		btnselect.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent e) {
//					
					int selectedCount =0;
    				for(int i=0; i<table.getItemCount();i++ ) {
    					if(table.getItem(i).getChecked()==true) 
    						selectedCount++;
    				}
					String[] selectedVersions = new String [selectedCount];
					int index = 0;
    				for(int i=0; i<table.getItemCount();i++ ) {
    					if(table.getItem(i).getChecked()==true) {
    						selectedVersions[index]=table.getItem(i).toString();
    						System.out.println("Selected:" + selectedVersions[index]);
    						index++;}
    						}
    				int[] vs = new int [readList.size()];
    				for(int i=0;i<readList.size();i++) {

    					String la =readList.toArray()[i].toString().split("_")[0];
    					String temp = la.split("version")[1];
    					int v= Integer.parseInt(temp);
    					vs[i] = v;
    				}

    				int maxversion = Arrays.stream(vs).max().getAsInt();
    				maxversion++;

    				String newVersion = "version"+ String.valueOf(maxversion);
    				String[] verR = new String [selectedVersions.length];
    				for(int i=0;i<selectedVersions.length;i++) {
    					verR[i] = selectedVersions[i]+' '+ newVersion;
    					verR[i] = verR[i].substring(verR[i].indexOf("{")+1,verR[i].indexOf("}"));
    					System.out.println("New:" +verR[i]);
    				}
    				System.out.println("Merged Version��" + newVersion);
    				
    				setTxt(file,newVersion);
    				for(int i=0;i<selectedVersions.length;i++) {
    					setTxt(filer,verR[i]+" "+newVersion);
    				}
    				//String[] verR is the list of selected versions
    				//mergeXML(verR)
    				
    					try {
							createClassView.main(verR);//���ɺϲ����ģ��
						} catch (Exception e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
			
    				Display display = Display.getDefault();
    				final Shell shell = new Shell(display);
    		        MessageBox dialog=new MessageBox(shell,SWT.OK|SWT.ICON_INFORMATION);
    		        dialog.setText("N Way Model Merge Tool");
    		        dialog.setMessage("Successfully Merged!");
    		        dialog.open();
    				for(int i=0; i<table.getItemCount();i++ ) 
    					table.getItem(i).setChecked(false);

    				final IWorkbench workbench = PlatformUI.getWorkbench();
    				final IWorkbenchPage activePage = workbench.getActiveWorkbenchWindow().getActivePage();
    				IWorkbenchPart part = activePage.getActivePart();
    				activePage.hideView((IViewPart) part);
    				try {
						activePage.showView(ID);
					} catch (PartInitException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
   			}
    		});

 
    		Button btnAll = new Button(tableGroup, 1);
    		btnAll.setText("Select All");
    		btnAll.addSelectionListener(new SelectionAdapter() {
    			public void widgetSelected(SelectionEvent e) {
    				for(int i=0; i<table.getItemCount();i++ ) 
    					table.getItem(i).setChecked(true);
    			}
    		});
    		Button btnclear = new Button(tableGroup, 1);
    		btnclear.setText("Deselect All");
    		btnclear.addSelectionListener(new SelectionAdapter() {
    			public void widgetSelected(SelectionEvent e) {
    				for(int i=0; i<table.getItemCount();i++ ) 
    					table.getItem(i).setChecked(false);
    			}
    		});
    		Button test = new Button(tableGroup, 1);
    		test.setText("test");
    		test.addSelectionListener(new SelectionAdapter() {
    			public void widgetSelected(SelectionEvent e) {

    				
    			}
    		});
        
        }

      //The second tab "Upload and Download"
        TabItem tabItem2 = new TabItem(tabFolder,SWT.NONE);
        tabItem2.setText("Upload and Download");
	    Composite compsoite2 = new Composite(tabFolder,SWT.NONE|SWT.V_SCROLL);
	    tabItem2.setControl(compsoite2);
	    Label l2 = new Label(compsoite2, 0);
	    l2.setText("Existing Versions");
	  	Canvas canvas2 = new Canvas(compsoite2, SWT.BORDER);
	  	canvas2.setLayoutData(gridA);
	  	canvas2.addPaintListener(new PaintListener() {
	  	            public void paintControl(PaintEvent e) {
	  	                if(image!=null)
	  	                    e.gc.drawImage(image, 0, 0);
	  	            }
	  	        });
	  	canvas2.redraw();
	    GridLayout layout2 = new GridLayout();
	    layout2.numColumns = 1;
	    compsoite2.setLayout(layout2);
        Group newGroup = new Group(compsoite2,SWT.V_SCROLL);
        newGroup.setText("Versions");
        GridData gd2 = new GridData(GridData.FILL_BOTH);
        gd2.heightHint = 200;
        newGroup.setLayoutData(gd2);
        newGroup.setLayout(new GridLayout(2,false));
        {    //����һ����ѡ�ģ��б߽�ģ�һ��ȫѡ�ı���
           Table table = new Table(newGroup, SWT.CHECK | SWT.BORDER |SWT.V_SCROLL);
            table.setHeaderVisible(true);//���ñ�ͷ�ɼ�
            table.setLinesVisible(true);//���������ɼ�
//            table.setLayoutData(new GridData(GridData.FILL_BOTH));
            GridData gridData = new GridData(GridData.FILL_BOTH);
            gridData.horizontalAlignment=SWT.FILL;//ˮƽ���
            gridData.horizontalSpan=2;
            table.setLayoutData(gridData);
            table.setSize(150, 150);

            TableColumn column1 = new TableColumn(table,SWT.NULL);
            column1.setText("Version");
            column1.pack();
            column1.setWidth(150);

			for(int i=0;i<readList.size();i++) {
				TableItem  item = new TableItem(table, SWT.NONE);
	            item.setText(readList.toArray()[i].toString());
			}
//			buttonUpload
			Button btnUpload = new Button(newGroup, 1);
			btnUpload.setText("Upload");
			btnUpload.addSelectionListener(new SelectionAdapter() {
    			public void widgetSelected(SelectionEvent e) {
    				Display display = Display.getDefault();
    				final Shell shell = new Shell(display);
    				FileDialog fileselect=new FileDialog(shell,SWT.SINGLE); 
                    fileselect.setFilterNames(new String[]{"*.rar","�����ļ�"}); 
                    fileselect.setFilterExtensions(new String[]{"*.rar","*.*"}); 
                   String url=""; 
                   url=fileselect.open();
                   System.out.println(url);
                   String filename = fileselect.getFileName();
                   System.out.println(filename);
                   String parentname = filename.split("_")[0];
                   System.out.println("parentname��"+ parentname);
                   System.out.println("ԭ���ǣ�"+filename);
                   String name = filename.split("\\.")[0];
                   System.out.println("name��"+ name);

                   setTxt(file,name);
                   setTxt(filer,parentname + " " + name);
                   
           		// Redraw picture of existing versions   
                String projectPath = System.getProperty("user.dir");
   				String file = new String(projectPath+"\\Models\\version_info.txt");
   				String filer = new String(projectPath+"\\Models\\version_r.txt");
   				ArrayList<String> readListr = getTxt(filer);
   				ArrayList<String> readList = getTxt(file);
   				test t = new test();
   				t.main(null, readList, readListr);

   				final IWorkbench workbench = PlatformUI.getWorkbench();
   				final IWorkbenchPage activePage = workbench.getActiveWorkbenchWindow().getActivePage();
   				IWorkbenchPart part = activePage.getActivePart();
   				activePage.hideView((IViewPart) part);
   				try {
						activePage.showView(ID);
						
					} catch (PartInitException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

   			}
    		});
			Button btnDownload = new Button(newGroup, 0);
			btnDownload.setText("Download");
			btnDownload.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent e) {
    				Display display = Display.getDefault();
    				final Shell shell = new Shell(display);

    					//�½��ļ��У�Ŀ¼���Ի��� 
    					DirectoryDialog folderdlg=new DirectoryDialog(shell); 
    					//�����ļ��Ի���ı��� 
    					folderdlg.setText("Select download path"); 
    					//���ó�ʼ·�� 
    					folderdlg.setFilterPath("SystemDrive"); 
    					//���öԻ�����ʾ�ı���Ϣ 
    					folderdlg.setMessage("Select download path"); 
    					//���ļ��Ի��򣬷���ѡ���ļ���Ŀ¼ 
    					String selecteddir=folderdlg.open(); 
    					if(selecteddir==null){ 
    					return ; 
    					} 
    					else{ 
    					System.out.println("Selected download path is:"+selecteddir); 
    					
    					} 
    					
   			}

			});
			
			
        }
    }
	public static ArrayList<String> getTxt(String filepath){
	  try{
	    String temp = null;
	    File f = new File(filepath);
	    String adn="";
	    InputStreamReader read = new InputStreamReader(new FileInputStream(f),"GBK");
	    ArrayList<String> readList = new ArrayList<String>();
	    BufferedReader reader=new BufferedReader(read); 
	    while((temp=reader.readLine())!=null &&!"".equals(temp)){
	       readList.add(temp);
	    }
	    read.close();
	    return readList;
	    }catch (Exception e) {
	         // TODO: handle exception
	          e.printStackTrace();
	          return null;
	    }  
	}
	public static void setTxt(String file, String conent) {   
	    BufferedWriter out = null;   
	     try {   
	         out = new BufferedWriter( new OutputStreamWriter(   
	                   new FileOutputStream(file, true)));   
	                 out.newLine();
	                 out.write(conent);   
	        } catch (Exception e) {   
	            e.printStackTrace();   
	        } finally {   
	             try {   
	                out.close();   
	            } catch (IOException e) {   
	                e.printStackTrace();   
	            }   
	        }   
	    }   
	public static void setTxt1(String file, String conent) {   
	    BufferedWriter out = null;   
	     try {   
	         out = new BufferedWriter( new OutputStreamWriter(   
	                   new FileOutputStream(file, true)));   
	                 out.write(conent);   
	        } catch (Exception e) {   
	            e.printStackTrace();   
	        } finally {   
	             try {   
	                out.close();   
	            } catch (IOException e) {   
	                e.printStackTrace();   
	            }   
	        }   
	    }  
	@Override
	public void setFocus() {
		
	}

}
