package com.nway.utils;

import java.util.ArrayList;
import java.util.List;

public class ClassType {
private String version;//�������ڵİ汾����version1_u1
private String className;
private String classID;
private List <String> Pro;
private List <String> Oper;
private List <String> Relationships;

public String getversion() {
	return version;
}
public void setversion(String version) {
	this.version=version;
}
public String getclassName() {
	return className;
}
public void setclassName(String className) {
	this.className = className;
}
public String getclassID() {
	return classID;
}
public void setclassID(String classID) {
	this.classID = classID;
}
public List<String> getPro() {
	return Pro;
}
public void setPro(List<String> Pro) {
	this.Pro = Pro;
}
public List<String> getOper() {
	return Oper;
}
public void setOper(List<String> Oper) {
	this.Oper = Oper;
}
public List<String> getProAndOper() {
	List<String> ProAndOper = new ArrayList<String>();
	for(String pro:Pro) {
		ProAndOper.add(pro);
	}
	for(String oper:Oper) {
		ProAndOper.add(oper);
	}
	return ProAndOper;
}

public List<String> getRelationships() {
	return Relationships;
}
public void setRelationships(List<String> Relationships) {
	this.Relationships = Relationships;
}
}
