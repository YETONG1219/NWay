package com.nway.utils;

public class RelationType {
	private String version;//�������ڵİ汾����version1_u1
	private String sourceID;//ԴID
	private String sourceName;//ԴName
	private String destinationID;//Ŀ��ID
	private String destinationName;//Ŀ��Name
	private String type;//dependency,generalization 
	private String ID;
	private int lowerValue;//������ϵ�Ķ�����
	private int upperValue;
	public int getlowerValue() {
		return lowerValue;
	}
	public void setlowerValue(int lowerValue) {
		this.lowerValue=lowerValue;
	}
	public int getupperValue() {
		return upperValue;
	}
	public void setupperValue(int upperValue) {
		this.upperValue=upperValue;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version=version;
	}
	public String getID() {
		return ID;
	}
	public void setID(String ID) {
		this.ID=ID;
	}
	public String getSourceID() {
		return sourceID;
	}
	public void setSourceID(String sourceID) {
		this.sourceID=sourceID;
	}
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName=sourceName;
	}
	public String getDestinationID() {
		return destinationID;
	}
	public void setDestinationID(String destinationID) {
		this.destinationID=destinationID;
	}
	public String getDestinationName() {
		return destinationName;
	}
	public void setDestinationName(String destinationName) {
		this.destinationName=destinationName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type=type;
	}

}
